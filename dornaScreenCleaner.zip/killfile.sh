#!/bin/sh
# Input argument should be the PID of the process to kill

# Force kill specified process
sudo kill -9 ${1}


